require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');

// User details
const users = [
  {
    idNumber: '2020-0001',
    firstName: 'Admin',
    lastName: 'User',
    email: 'admin@example.com',
    username: 'admin',
    password: 'password123',
    role: 'admin'
  },
  {
    idNumber: '2020-0002',
    firstName: 'Lecturer',
    lastName: 'User',
    email: 'lecturer@example.com',
    username: 'lecturer',
    password: 'password123',
    role: 'lecturer'
  },
  {
    idNumber: '2020-0003',
    firstName: 'Student',
    lastName: 'User',
    email: 'student@example.com',
    username: 'student',
    password: 'password123',
    role: 'student'
  }
];

// Connect to MongoDB
console.log('Connecting to MongoDB...');
console.log('MongoDB URI:', process.env.MONGODB_URI);

mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/projectx', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  serverSelectionTimeoutMS: 5000,
  socketTimeoutMS: 45000
})
.then(async () => {
  console.log('Connected to MongoDB successfully');
  
  try {
    // Process each user
    for (const userData of users) {
      // Check if user already exists
      const existingUser = await User.findOne({ username: userData.username });
      
      if (existingUser) {
        console.log(`User ${userData.username} already exists!`);
      } else {
        // Create new user
        const newUser = new User(userData);
        await newUser.save();
        
        console.log(`User ${userData.username} (${userData.role}) created successfully!`);
        console.log(`Password: ${userData.password}`);
      }
    }
    
    console.log('\nAll users processed. You can now log in with these credentials:');
    console.log('Admin: username=admin, password=password123');
    console.log('Lecturer: username=lecturer, password=password123');
    console.log('Student: username=student, password=password123');
    
  } catch (error) {
    console.error('Error:', error);
  } finally {
    // Close the database connection
    mongoose.connection.close();
    console.log('Database connection closed');
  }
})
.catch(err => {
  console.error('MongoDB connection error:', err);
});
