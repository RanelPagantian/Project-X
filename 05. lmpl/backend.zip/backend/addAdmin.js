require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');

// Admin user details
const adminUser = {
  idNumber: '2020-0001',
  firstName: 'Admin',
  lastName: 'User',
  email: 'admin@example.com',
  username: 'admin',
  password: 'password123',
  role: 'admin'
};

// Connect to MongoDB
console.log('Connecting to MongoDB...');
console.log('MongoDB URI:', process.env.MONGODB_URI);

mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/projectx', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  serverSelectionTimeoutMS: 5000,
  socketTimeoutMS: 45000
})
.then(async () => {
  console.log('Connected to MongoDB successfully');
  
  try {
    // Check if admin user already exists
    const existingUser = await User.findOne({ username: adminUser.username });
    
    if (existingUser) {
      console.log('Admin user already exists!');
      console.log('Username:', existingUser.username);
      console.log('Password: password123 (default password)');
    } else {
      // Create new admin user
      const newAdmin = new User(adminUser);
      await newAdmin.save();
      
      console.log('Admin user created successfully!');
      console.log('Username:', adminUser.username);
      console.log('Password:', adminUser.password);
    }
  } catch (error) {
    console.error('Error:', error);
  } finally {
    // Close the database connection
    mongoose.connection.close();
    console.log('Database connection closed');
  }
})
.catch(err => {
  console.error('MongoDB connection error:', err);
});
